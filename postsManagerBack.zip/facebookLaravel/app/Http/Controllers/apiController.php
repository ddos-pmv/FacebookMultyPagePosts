<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;

class apiController extends Controller
{
    public function getData(Request $req)
    {
    }
}
