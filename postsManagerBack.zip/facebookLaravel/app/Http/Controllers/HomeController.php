<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Illuminate\Http\Response;

use App\Models\Pages;
use Illuminate\Support\Facades\Cookie;
use Laravel\Socialite\Facades\Socialite;
use App\Models\User;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    // public function welcome()
    // {
    //     if (Cookie::get('id')) {
    //         return view('page');
    //     } else {
    //         return view('welcome');
    //     }
    // }
    // public function login()
    // {

    //     return Socialite::driver('facebook')
    //         ->setScopes(['email', 'pages_manage_posts', 'pages_read_engagement'])
    //         ->redirect();
    //     // return redirect('/callBack');
    // }
    // public function callBack()
    // {
    //     $res = Socialite::driver('facebook')->user();
    //     $data = [
    //         'name' => $res->name,
    //         'email' => $res->email,
    //         'token' => $res->token,
    //         'avatar' => $res->avatar,
    //         'id' => $res->id


    //     ];
    //     // $data = [
    //     //     'name' => 'sergey',
    //     //     'email' => 'email@email.com',
    //     //     'token' => 'longlonglongveryveryverylong TOKEN',
    //     //     'avatar' => 'urlForAvatr',
    //     //     'id' => '14888322hui'
    //     // ];

    //     $client = new \GuzzleHttp\Client();
    //     try {
    //         // Запрос к Graph API для получения списка страниц пользователя
    //         $response = $client->get('https://graph.facebook.com/v18.0/me/accounts', [
    //             'query' => [
    //                 'access_token' => $data['token'],
    //             ],
    //         ]);

    //         $dataJson = json_decode($response->getBody());

    //         foreach ($dataJson->data as $pageData) {
    //             // Вывод информации о каждой странице
    //             $existingPage = Pages::where([
    //                 'pageId' =>  $pageData->id,
    //                 'name' => $pageData->name,
    //             ])->first();

    //             if (!$existingPage) {
    //                 $page = new Pages;
    //                 $page->userToken = $data['token'];
    //                 $page->pageId = $pageData->id;
    //                 $page->name = $pageData->name;
    //                 $page->save();
    //             }
    //             echo $pageData->id . "<br>";
    //         }
    //     } catch (\Exception $e) {
    //         echo 'Ошибка при получении списка страниц: ' . $e->getMessage();
    //     }

    //     $existingUser = User::where([
    //         'email' => $data['email'],
    //         'name' => $data['name'],
    //     ])->first();

    //     if (!$existingUser) {
    //         $user = new User;
    //         $user->userToken = $data['token'];
    //         $user->email = $data['email'];
    //         $user->name = $data['name'];
    //         $user->save();
    //         echo "added";
    //     } else {
    //         echo "was added earlier";
    //     }


    //     //отправка поста
    //     $pageId = '104012352806036';

    //     $client = new Client();
    //     try {
    //         $response = $client->get("https://graph.facebook.com/v18.0/{$pageId}", [
    //             'query' => ['access_token' => $data['token']],
    //         ]);

    //         $dataToken = json_decode($response->getBody());

    //         print_r($dataToken);


    //         $pageToken = 'EAAE4j6fjaE0BO10gs3I52n3sUZBiPcF18ySRdtrtLZAJv3OwDM8rZATErKaSaZA1AszmQhyujykEUVqttlf6rIiatNYIF8g9nTEDgn7AwVFuWGIFfba4jnCRtDGTZAb45XN7hSIzUirUQgvGgTBAEyegtkdtmMcCR3K5cJkhnJKLY9gzxpnZCLPEEe8UxtgBlZAfZALmCczItfbvZAe4cTHaFwnEVBDSpYVgZD';
    //     } catch (\Exception $e) {
    //         echo 'Ошибка при получении access page token: ' . $e->getMessage();
    //     }

    //     $client = new Client();

    //     try {
    //         $response = $client->post("https://graph.facebook.com/{$pageId}/feed", [
    //             'query' => ['access_token' => $pageToken],
    //             'json' => [
    //                 'message' => 'Текст вашего поста на странице',
    //             ],
    //         ]);

    //         $dataPost = json_decode($response->getBody());

    //         if (isset($dataPost->id)) {
    //             // Пост успешно опубликован на странице
    //         } else {
    //             // Возникла ошибка при публикации
    //             throw new Exception('Пост не был опубликован');
    //         }
    //     } catch (\Exception $e) {
    //         echo 'Ошибка при публикации поста: ' . $e->getMessage();
    //     }



    //     // return redirect('/')->withCookie(cookie('id', $data['token'], 2, "/"));

    //     // $minutes = 60;
    //     // $response = new Response('Set Cookie');
    //     // $response->withCookie(cookie('name', 'MyValue', $minutes));
    //     // return $response;

    //     // return redirect('/');
    // }
    // public function logout()
    // {
    //     return redirect('/')
    //         ->withCookie(Cookie::forget('id'));
    // }
    public function download()
    {
        Crypt::encrypt("1");

        return $path;
    }
}
