<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Posts extends Model
{
    use HasFactory;
    protected $table = 'posts'; // Укажите имя вашей таблицы users
    public $timestamps = false;

    protected $fillable = [
        'userToken',
        'pageId', 'message'
    ];
}
