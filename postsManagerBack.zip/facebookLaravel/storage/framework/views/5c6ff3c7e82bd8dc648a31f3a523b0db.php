<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <a href="<?php echo e(route('logout')); ?>">LOG OUT</a>
</body>

</html><?php /**PATH C:\MAMP\htdocs\facebookLaravel\resources\views/page.blade.php ENDPATH**/ ?>